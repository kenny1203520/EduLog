// Shared extension-owned presentation. Provider content is never registered here.
(() => {
  if (globalThis.edulogUi) return
  const catalog = {
    'ui.language': ['介面語言', 'Interface language'],
    'ui.settings': ['設定', 'Settings'],
    'ui.navigation': ['網站導覽', 'Site navigation'],
    'ui.integration': ['EduLog 功能', 'EduLog tools'],
    'ui.integrationPanel': ['EduLog 連線與整合', 'EduLog connection and tools'],
    'ui.closePanel': ['關閉 EduLog 整合面板', 'Close EduLog tools'],
    'ui.themeOn': ['套用清晰主題', 'Use light theme'],
    'ui.themeOff': ['使用原站主題', 'Use original theme'],
    'ui.work': ['繼續工作／工作紀錄', 'Continue work / work history'],
    'ui.sourceTeaching': ['原站教學 · 工作台同步', 'Teach here · sync in the workspace'],
    'flow.import': ['同步教學資料', 'Sync teaching data'],
    'flow.importHelp': ['讀取完整歷史，集中核對例外與同步摘要。', 'Read full history, review exceptions, and confirm the sync summary.'],
    'flow.prefill': ['預填目前報告', 'Prefill current report'],
    'flow.prefillHelp': ['在原站核對欄位，再由您人工送出。', 'Review fields in the source form, then submit it yourself.'],
    'flow.details': ['操作說明', 'How it works'],
    'flow.ready': ['可開始', 'Ready'],
    'flow.notReady': ['此操作未就緒', 'Operation unavailable'],
    'flow.connect': ['先完成連線', 'Connect first'],
    'flow.unavailable': ['此連線未提供這項操作，請重新檢查連線或查看診斷。', 'This connection does not provide this operation. Recheck it or view diagnostics.'],
    'work.saved': ['草稿已保存在此瀏覽器', 'Draft saved in this browser'],
    'work.unsaved': ['正在保存草稿…', 'Saving draft…'],
    'work.ready': ['尚未開始工作', 'No work started'],
    'work.saveFailed': ['草稿保存失敗。上次成功保存：{savedAt}', 'Draft save failed. Last saved: {savedAt}'],
    'work.retrySaveContinue': ['重試保存並繼續讀取', 'Retry saving and continue reading'],
    'work.settings': ['本次同步設定', 'Settings for this sync'],
    'work.settingsHelp': ['共用規則與欄位偏好；逐份報告可另外調整。', 'Shared rules and field preferences; each report can be adjusted separately.'],
    'work.continue': ['繼續未完成工作', 'Continue unfinished work'],
    'work.new': ['建立新工作', 'Start new work'],
    'work.resumeHelp': ['此來源已有未完成草稿，請選擇繼續或建立新工作。', 'There is an unfinished draft for this source. Continue it or start new work.'],
    'work.remaining': ['處理剩餘項目', 'Resolve remaining items'],
    'work.filter': ['工作狀態', 'Work status'],
    'work.all': ['全部工作', 'All work'],
    'work.resumable': ['可繼續', 'Can continue'],
    'work.attention': ['需要處理', 'Needs attention'],
    'work.done': ['已完成', 'Completed'],
    'work.local': ['本機草稿', 'Local draft'],
    'work.remote': ['EduLog 紀錄', 'EduLog record'],
    'work.merged': ['本機草稿＋EduLog 紀錄', 'Local draft + EduLog record'],
    'work.filteredEmpty': ['此篩選沒有工作紀錄。', 'No work matches this filter.'],
    'work.identity':['身份與課程','Identity and courses'],
    'work.reports':['報告例外','Report exceptions'],
    'work.reason':['依問題篩選','Filter by issue'],
    'work.allReasons':['所有原因','All reasons'],
    'work.date':['日期','Date'],
    'work.field':['欄位映射','Field mapping'],
    'work.sourceConflict':['來源矛盾','Source conflicts'],
    'work.occurrence':['課次','Session'],
    'work.overwrite':['覆寫確認','Overwrite review'],
    'work.reviewed':['已核對','Reviewed'],
    'work.remainingIssues':['待處理問題 · {count} 項','Issues to resolve · {count}'],
    'work.reviewComplete':['已核對，待同步','Reviewed, ready to sync'],
    'work.actionSummary':['待處理 {reports} 份報告 · {issues} 個問題 · 可同步 {ready} 份','{reports} reports need review · {issues} issues · {ready} ready to sync'],
    'work.conflictSaving':['已記錄選擇，正在計入摘要並保存草稿…','Choice recorded. Updating the summary and saving the draft…'],
    'work.conflictSaved':['已核對並保存草稿；可於同步摘要再次確認。','Reviewed and saved as a draft. Confirm again in the sync summary.'],
    'work.conflictSaveFailed':['保存失敗，選擇仍保留；請重試保存。','Save failed. Your choice is preserved; retry the save.'],
    'work.conflictConfirmed':['已核對並保存草稿','Reviewed and saved'],
    'work.conflictRetry':['重試保存核對結果','Retry saving review'],
    'work.reportSaved':['已確認並保存草稿。','Confirmed and saved as a draft.'],
    'work.reportSaveFailed':['保存失敗，請重試。','Save failed. Please retry.'],
    'work.batchSaving':['正在保存套用至 {count} 份報告的本次決定…','Saving this decision for {count} reports…'],
    'work.batchSaved':['已套用並保存至 {count} 份報告；僅限本次工作。','Applied and saved for {count} reports in this work only.'],
    'work.saveConflict':['工作已在其他分頁更新；目前草稿保留，請重新載入後核對。','This work changed in another tab. Your draft is preserved; reload and review it.'],
    'work.count':['顯示 {visible}／{total} 份工作紀錄','Showing {visible} of {total} work records'],
    'assistant.apply': ['套用 {count} 個欄位 · 覆寫 {overwrite} 個', 'Apply {count} fields · overwrite {overwrite}'],
    'assistant.target': ['1 · 核對目標', '1 · Review target'],
    'assistant.candidates': ['2 · 選擇報告', '2 · Choose report'],
    'assistant.fields': ['3 · 核對欄位', '3 · Review fields'],
    'assistant.result': ['4 · 套用結果 · 待人工送出', '4 · Applied fields · submit manually'],
    'assistant.refresh': ['重新核對', 'Recheck'],
    'assistant.collapse': ['收合助手', 'Collapse assistant'],
    'assistant.expand': ['展開 EduLog 助手', 'Open EduLog assistant'],
    'assistant.native': ['原站表單', 'Source form'],
    'assistant.tab': ['EduLog 預填', 'EduLog prefill'],
    'assistant.title': ['EduLog 報告助手', 'EduLog report assistant'],
    'work.previewRefresh':['更新差異','Refresh differences'],
    'work.applyBatches':['確認並分批匯入','Confirm and import batches'],
    'work.previewBlockedRow':['已將無法核對的 {kind} {sourceId} 留在待處理；其他資料繼續檢查。','{kind} {sourceId} could not be verified and remains blocked; checking the other records.'],
    'error.importDependenciesUnavailable':['目前連線的 EduLog 尚不能安全核對跨批次報名關係。請重新檢查連線後重試；待處理資料仍保留。','The connected EduLog cannot safely verify cross-batch enrollment references yet. Recheck the connection and retry; blocked records remain available.'],
    'error.workConflict':['工作已在其他分頁更新；目前草稿保留，請重新載入後核對。','This work changed in another tab. Your draft is preserved; reload and review it.'],
    'error.workDataInvalid':['工作資料格式無效；本機草稿尚未變更。','The work data is invalid. The saved draft was not changed.'],
    'error.workStorageFull':['此瀏覽器的工作儲存空間不足。請移除不需要的本機工作草稿後重試。','This browser is low on storage. Remove unneeded local work drafts and retry.'],
    'error.workDataCorrupt':['本機草稿分段無法完整還原；保留其他工作並重新讀取此班級。','The local draft is incomplete. Other work is preserved; reread this class.'],
    'error.workSaveFailed':['本機草稿保存失敗；先前保存的內容仍保留。請重試。','The local draft could not be saved. The last saved version is preserved; retry.'],
    'error.workOwnerMismatch':['這份工作屬於其他 EduLog 實例或使用者。','This work belongs to another EduLog instance or user.'],
    'work.savedAtUnknown':['尚無成功保存版本','no successful save'],
    'work.previewPartial':['摘要已準備。部分資料待處理；確認後只會同步可處理資料。','Summary ready. Some records need attention; confirming will sync only eligible records.'],
    'work.blockedCount':['被阻擋的來源資料：{count} 筆','Blocked source records: {count}'],
    'work.blockedSummary':['待處理來源資料：{count} 筆。確認後僅同步已核對的資料；被阻擋資料會保留在工作中。','Blocked source records: {count}. Confirming syncs only verified records; blocked records remain in this work.'],
    'work.applyEligible':['僅同步可處理資料','Sync eligible records only'],
    'work.confirmEligible':['仍有 {count} 筆來源資料無法核對。確認後只會寫入可處理批次，待處理資料會保留。要繼續嗎？','{count} source records could not be verified. Only eligible batches will be written, and blocked records will remain. Continue?'],
    'work.sourceChoice':['來源分頁 · 查看／修改','Source tab · view / change'],
    'work.conflictHelp':['衝突預設保留 EduLog。勾選改用來源欄位後，必須重新產生差異。','Conflicts keep EduLog values by default. After selecting source values, refresh the preview.'],
    'work.import1':['1 讀取與核對','1 Read and review'],'work.import2':['2 處理例外','2 Resolve exceptions'],'work.import3':['3 摘要並同步','3 Review and sync'],'work.import4':['4 匯入結果','4 Import results'],
    'work.prefill1':['1 確認目標','1 Confirm target'],'work.prefill2':['2 選擇報告','2 Choose report'],'work.prefill3':['3 檢查欄位','3 Review fields'],'work.prefill4':['4 套用至原站','4 Apply to source'],
    'work.state.collected':['已讀取，待核對','Read; review required'],'work.state.collecting':['正在讀取','Reading…'],'work.state.reviewing':['正在核對','Reviewing…'],'work.state.previewed':['摘要待確認','Summary requires confirmation'],'work.state.applying':['正在寫入','Writing…'],'work.state.paused':['已暫停','Paused'],'work.state.failed':['需要處理','Needs attention'],'work.state.outcome_unknown':['寫入結果待核對','Write outcome requires verification'],'work.state.partial_complete':['部分完成','Partially complete'],'work.state.complete':['已核驗完成','Verified complete'],'work.state.pending_confirm':['待人工送出／待確認','Manual submission required'],'work.state.cancelled':['已取消剩餘工作','Remaining work cancelled'],
    'flow.importStep1':['讀取每筆報名全部可讀歷史，可自行縮小日期範圍。','Read all accessible enrollment history, or choose a date range.'],
    'flow.importStep2':['沿用有效對應，只處理身份、日期、教材及覆寫例外。','Reuse valid matches and resolve identity, date, lesson, and overwrite exceptions.'],
    'flow.importStep3':['查看摘要後確認同步；寫入中斷可核對並續傳。','Review the summary and confirm sync. Interrupted writes can be checked and resumed.'],
    'flow.prefillStep1':['在原站開啟報告，核對學生及完整上課日期。','Open a source report and verify the student and full session date.'],
    'flow.prefillStep2':['選擇報告並逐欄預覽；非空內容需確認覆寫。','Choose a report and preview each field. Confirm overwrites of existing values.'],
    'flow.prefillStep3':['預填後由老師檢查與人工送出。','After prefilling, the teacher reviews and submits the source form.'],
  }
  let locale = /^en(?:-|$)/i.test(globalThis.navigator?.language || '') ? 'en' : 'zh-TW'
  const bindings = new Map(), listeners = new Set()
  const normalize = value => value === 'en' ? 'en' : 'zh-TW'
  function t(key, params = {}) {
    const entry = catalog[key]
    return String(entry ? entry[locale === 'en' ? 1 : 0] : key).replace(/\{(\w+)\}/g, (_, name) => typeof params[name]==='number' ? new Intl.NumberFormat(locale).format(params[name]) : String(params[name] ?? ''))
  }
  function text(el, key, params = {}, attr) {
    if (!el) return el
    if (!attr) el.dataset.i18n = key
    bindings.set(el, { key, params, attr }); update(el, bindings.get(el)); return el
  }
  function update(el, binding) { const value = t(binding.key, typeof binding.params === 'function' ? binding.params() : binding.params); if (binding.attr) el.setAttribute(binding.attr, value); else el.textContent = value }
  function bind(root) { for (const el of root.querySelectorAll('[data-i18n]')) text(el, el.dataset.i18n, {}, el.dataset.i18nAttr) }
  function setLocale(value) {
    const next = normalize(value), changed = next !== locale; locale = next
    // Capture geometry before translated labels change wrapping. Keep the actual
    // controls, focus and selection; restore scroll after compatibility observers.
    const positions=[],collect=root=>{for(const el of root?.querySelectorAll?.('*')||[]){if(el.scrollTop||el.scrollLeft)positions.push([el,el.scrollTop,el.scrollLeft]);if(el.shadowRoot)collect(el.shadowRoot)}}
    if(changed)collect(globalThis.document)
    const pageY=globalThis.scrollY||0,pageX=globalThis.scrollX||0
    for (const [el, binding] of bindings) { if (!el.isConnected) { bindings.delete(el); continue } update(el, binding) }
    if (changed) for (const listener of listeners) listener(locale)
    if(changed&&globalThis.requestAnimationFrame)requestAnimationFrame(()=>requestAnimationFrame(()=>{if(locale!==next)return;for(const [el,top,left] of positions)if(el.isConnected){el.scrollTop=top;el.scrollLeft=left}globalThis.scrollTo?.({top:pageY,left:pageX,behavior:'instant'})}))
  }
  async function saveLocale(value) {
    setLocale(value)
    // The worker validates both the sender and the bounded language value.
    const result = await globalThis.edulogRuntime?.send({ type: 'set-ui-preferences', language: normalize(value) })
    if (result?.error) throw new Error('PREFERENCES_UNAVAILABLE')
  }
  function languageSelect(doc = document) {
    const select = doc.createElement('select'); text(select, 'ui.language', {}, 'aria-label')
    for (const [value, label] of [['zh-TW', '繁體中文'], ['en', 'English']]) { const option = doc.createElement('option'); option.value = value; option.textContent = label; select.append(option) }
    select.value = locale; select.addEventListener('change', () => void saveLocale(select.value).catch(() => {})); subscribe(value => { select.value = value }); return select
  }
  function subscribe(listener) { listeners.add(listener); return () => listeners.delete(listener) }
  const styles = `:host{--ui-primary:#2563eb;--ui-text:#0f172a;--ui-muted:#475569;--ui-border:#cbd5e1;--ui-surface:#fff;font:16px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif;color:var(--ui-text)}button,input,select,textarea{font:inherit;min-height:44px}small,.hint,.muted,.note{font-size:14px}button,input,select,textarea,a,summary{scroll-margin:80px 0}button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible,a:focus-visible,summary:focus-visible{outline:3px solid #2563eb;outline-offset:3px}[hidden]{display:none!important}`
  globalThis.edulogUi = Object.freeze({ t, text, bind, setLocale, saveLocale, subscribe, languageSelect, styles, get locale() { return locale }, register(entries) { Object.assign(catalog, entries) } })
  globalThis.chrome?.storage?.onChanged?.addListener((changes, area) => { if (area === 'local' && changes.edulogWorkspaceLocale?.newValue) setLocale(changes.edulogWorkspaceLocale.newValue) })
  if (globalThis.chrome?.storage?.local?.get) void globalThis.chrome.storage.local.get('edulogWorkspaceLocale').then(data => { if (data.edulogWorkspaceLocale) setLocale(data.edulogWorkspaceLocale) }).catch(() => {})
})()
