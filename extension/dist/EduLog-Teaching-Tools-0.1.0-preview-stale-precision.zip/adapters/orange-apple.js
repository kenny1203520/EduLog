// Provider routes, selectors and terminology belong only in this adapter.
(() => {
  function matchPage(path) {
    if (/^\/my\/hour\/?$/.test(path)) return { kind: 'hours', title: '我的鐘點' }
    if (/^\/my\/?$/.test(path)) return { kind: 'profile', title: '個人資料' }
    if (/^\/my\/\d+\/edit\/?$/.test(path)) return { kind: 'profile-edit', title: '編輯個人資料' }
    if (path === '/') return { kind: 'overview', title: '教師總覽' }
    if (/^\/courses\/dt\/?$/.test(path)) return { kind: 'classes', title: '班級列表' }
    if (path === '/calendar') return { kind: 'calendar', title: '課程行事曆' }
    if (path === '/admissions/month_unfilled_report') return { kind: 'unfilled', title: '未填寫紀錄' }
    if (path === '/admissions/unfilled_report') return { kind: 'unfilled-current', title: '補填課堂紀錄' }
    if (/^\/dt_admissions\/\d+\/reports\/\d+\/edit\/?$/.test(path)) return { kind: 'report-editor', title: '課堂紀錄編輯' }
    if (/^\/dt_admissions\/\d+\/?$/.test(path)) return { kind: 'history', title: '學生學習紀錄' }
    if (/^\/courses\/dt\/\d+\/?$/.test(path)) return { kind: 'class', title: '班級工作區' }
    if (/^\/courses\/dt\/\d+\/lesson_reports\/?$/.test(path)) return { kind: 'reports', title: '課次報告' }
    return null
  }
  function createScope(doc) {
    const changes = new Map(), added = [], listeners = [], moves = [], texts = new Map()
    let restored = false
    return {
      text(node, value) { if (!node || node.textContent === value) return; if (!texts.has(node)) texts.set(node, [...node.childNodes]); node.textContent = value },
      mark(node, name, value = '') {
        if (!node) return
        if (!changes.has(node)) changes.set(node, new Map())
        const attrs = changes.get(node)
        if (!attrs.has(name)) attrs.set(name, node.getAttribute(name))
        if (value === null) node.removeAttribute(name)
        else node.setAttribute(name, value)
      },
      listen(node, event, handler) { node.addEventListener(event, handler); listeners.push(() => node.removeEventListener(event, handler)) },
      element(tag, text) { const node = doc.createElement(tag); node.dataset.edulogOwned = ''; if (text) node.textContent = globalThis.edulogUiLegacy?.translate(text) || text; if(text&&globalThis.edulogUiLegacy){const ownedText=node.firstChild;listeners.push(globalThis.edulogUi.subscribe(()=>{if(ownedText?.parentNode===node)ownedText.data=globalThis.edulogUiLegacy.translate(text)}))} return node },
      add(node) { added.push(node); return node },
      move(node, destination) {
        const anchor = doc.createElement('span'); anchor.dataset.edulogOwned = ''; anchor.hidden = true
        node.before(anchor); moves.push({ node, anchor }); destination.append(node)
      },
      restore() {
        if (restored) return
        restored = true
        for (const remove of listeners) remove()
        for (const { node, anchor } of [...moves].reverse()) {
          // A native update may have removed the moved field but left our anchor.
          if (anchor.isConnected && !node.isConnected) anchor.remove()
          else if (anchor.parentNode) anchor.replaceWith(node)
        }
        for (const node of [...added].reverse()) {
          // Keep native replacements inserted inside an extension wrapper.
          if (node.isConnected) {
            const preserve = container => {
              for (const child of [...container.children]) {
                if (child.hasAttribute('data-edulog-owned')) preserve(child)
                else node.before(child)
              }
            }
            preserve(node)
          }
          node.remove()
        }
        for (const [node, children] of texts) node.replaceChildren(...children)
        for (const [node, attrs] of changes) for (const [name, old] of attrs) {
          if (old === null) node.removeAttribute(name); else node.setAttribute(name, old)
        }
        listeners.length = moves.length = added.length = 0
        changes.clear(); texts.clear()
      },
    }
  }
  function enhancePage(doc, view = {}, documentMode = false) {
    const page = matchPage(doc.location.pathname)
    const content = doc.querySelector('#page-body > .content')
    if (!page || !content || /沒有存取權限|無權限|Access denied/i.test([...content.querySelectorAll('h1,h2')].map(h => h.textContent).join(' '))) return null
    const hoursForm = page.kind === 'hours' ? [...content.querySelectorAll('form')].find(form => ['year', 'month'].every(name => form.querySelector(`select[name=${name}]`)?.form === form)) : null
    if (page.kind === 'hours' && !hoursForm) return null
    const hoursInputs = hoursForm && ['year', 'month'].map(name => hoursForm.querySelector(`select[name=${name}]`))
    if (page.kind === 'profile' && (!content.querySelector('h1') || !content.querySelector('a[href^="/my/"][href$="/edit"]'))) return null
    if (page.kind === 'profile-edit' && !content.querySelector('form[action^="/my/"] .form-inputs')) return null
    const scope = createScope(doc)
    try {
    const { mark, listen, element } = scope
    const added = { push: node => scope.add(node) }
    function controls(table, label) {
      const box = element('div')
      box.className = 'edulog-table-tools'
      const field = element('label')
      field.append(element('span', label))
      const input = element('input')
      input.type = 'search'; input.placeholder = '搜尋目前頁面的學生'
      field.append(input)
      const count = element('span')
      count.setAttribute('role', 'status'); count.setAttribute('aria-live', 'polite')
      box.append(field, count); (table.closest('[data-edulog-scroll],.table-responsive') || table).before(box); added.push(box)
      return { box, input, count }
    }
    if (!documentMode) {
      mark(doc.documentElement, 'data-edulog-ui', 'on')
      mark(doc.documentElement, 'data-edulog-page', page.kind)
    }
    if (page.kind === 'overview') {
      const links = [...doc.querySelectorAll('.sidebar a[href]')].filter(a => {
        try { const url = new URL(a.href); return url.origin === doc.location.origin && /^\/courses\/dt\/\d+\/?$/.test(url.pathname) }
        catch { return false }
      })
      const unique = [...new Map(links.map(a => [a.href, a])).values()]
      if (unique.length) {
        const shortcuts = element('section')
        shortcuts.className = 'edulog-class-shortcuts'
        shortcuts.setAttribute('aria-label', '我的班級')
        shortcuts.append(element('h2', '我的班級'))
        const grid = element('div')
        for (const original of unique) {
          const link = element('a')
          link.href = original.href
          link.append(element('strong', original.textContent.trim()), element('span', '開啟班級工作區 →'))
          grid.append(link)
        }
        shortcuts.append(grid); content.prepend(shortcuts); added.push(shortcuts)
      }
    }
    let refreshStudents = () => {}, refreshReports = () => {}
    const students = content.querySelector('#students-table')
    if (students) {
      view.expandedStudents ||= new WeakSet()
      const { input, count } = controls(students, '目前名單篩選')
      input.dataset.edulogSearch = 'students'
      input.value = view.studentQuery || ''
      const headerRow = [...students.rows].find(r => [...r.cells].some(c => /姓名/.test(c.textContent))) || students.tHead?.rows[0]
      mark(headerRow, 'data-edulog-student-header', '')
      for (const row of students.rows) if (row.querySelector('#student_id-selectized') || row.querySelector('input[type=search],input[placeholder*="學生"]')) mark(row, 'data-edulog-student-search', '')
      const headers = [...(headerRow?.cells || [])].map(h => h.textContent.trim())
      const nameIndex = Math.max(0, headers.findIndex(h => /姓名/.test(h)))
      mark(headerRow?.cells[nameIndex], 'data-edulog-name', '')
      refreshStudents = () => {
        const rows = [...students.tBodies].flatMap(body => [...body.rows]).filter(row => row !== headerRow && !row.querySelector('th') && !row.hasAttribute('data-edulog-student-search'))
        let visible = 0
        for (const row of rows) {
          const matches = row.textContent.toLocaleLowerCase().includes(input.value.trim().toLocaleLowerCase())
          mark(row, 'data-edulog-filtered', matches ? null : '')
          if (matches) visible++
          for (const [index, cell] of [...row.cells].entries()) {
            mark(cell, 'data-edulog-label', headers[index] || '')
            if (index > 1 && !/姓名|年級|課程|操作/.test(headers[index] || '')) mark(cell, 'data-edulog-extra', '')
          }
          const nameCell = row.cells[nameIndex]
          mark(nameCell, 'data-edulog-name', '')
          if (nameCell && !nameCell.querySelector('[data-edulog-expand]')) {
            const button = element('button', '更多資料')
            button.type = 'button'; button.dataset.edulogExpand = ''
            const wasExpanded = view.expandedStudents.has(row)
            button.setAttribute('aria-expanded', String(wasExpanded))
            button.textContent = wasExpanded ? '收合資料' : '更多資料'
            mark(row, 'data-edulog-expanded', wasExpanded ? '' : null)
            listen(button, 'click', () => {
              const expanded = button.getAttribute('aria-expanded') !== 'true'
              button.setAttribute('aria-expanded', String(expanded))
              button.textContent = expanded ? '收合資料' : '更多資料'
              if (expanded) view.expandedStudents.add(row)
              else view.expandedStudents.delete(row)
              mark(row, 'data-edulog-expanded', expanded ? '' : null)
            })
            nameCell.append(button); added.push(button)
          }
        }
        const text = `顯示 ${visible} / ${rows.length} 位學生`
        if (count.textContent !== text) count.textContent = text
        view.studentQuery = input.value
      }
      listen(input, 'input', refreshStudents); refreshStudents()
    }
    const workflow = globalThis.edulogSiteWorkflows?.enhancePage({ doc, content, page, view, scope })
    const reports = content.querySelector('#reports')
    if (reports) {
      const reportScrollRegion=reports.closest('[data-edulog-scroll="reports"]')||reports.parentElement
      const { box, input, count } = controls(reports, '報告學生搜尋')
      input.dataset.edulogSearch = 'reports'
      input.value = view.reportQuery || ''
      const weekButtons = element('div')
      weekButtons.className = 'edulog-week-tools'
      weekButtons.setAttribute('role', 'group'); weekButtons.setAttribute('aria-label', '課次與顯示方式')
      const headers = [...reports.querySelectorAll('tr:first-child th')]
      const weeks = headers.map((h, index) => ({ label: h.textContent.trim(), index })).filter(h => /上週|本週|下週/.test(h.label))
      const selected = weeks.find(w => w.index === view.week) || weeks.find(w => /本週/.test(w.label)) || weeks[0]
      const countNumbers=[doc.createTextNode('0 / 0'),doc.createTextNode('0'),doc.createTextNode('0'),doc.createTextNode('0')]
      count.replaceChildren(element('span','顯示'),countNumbers[0],element('span','位學生 · 已確認出席'),countNumbers[1],element('span','· 已填紀錄'),countNumbers[2],element('span','· 狀態待確認'),countNumbers[3])
      const singleButton=element('button','單堂清單'),compareButton=element('button','三週比較')
      singleButton.type=compareButton.type='button';singleButton.dataset.reportMode='single';compareButton.dataset.reportMode='compare'
      listen(singleButton,'click',()=>selectMode('single'));listen(compareButton,'click',()=>selectMode('compare'))
      weekButtons.append(singleButton,compareButton)
      const dateContext = event => {
        const link = event.target.closest('a[data-edulog-record-action]')
        if (!link) return
        const row = link.closest('tr'), column = [...row.cells].indexOf(link.closest('td'))
        const label = reports.rows[0]?.cells[column]?.textContent.trim()
        if (label) view.reportTarget = { path: link.pathname, label }
      }
      listen(reports, 'click', dateContext)
      function selectMode(mode) {
        view.reportMode=mode==='compare'?'compare':'single'
        for(const button of [singleButton,compareButton])button.setAttribute('aria-pressed',String(button.dataset.reportMode===view.reportMode))
        mark(reports,'data-edulog-week-mode',view.reportMode)
        for(const button of weekButtons.querySelectorAll('[data-week]'))button.hidden=view.reportMode==='compare'
        if(typeof refreshReports==='function')refreshReports()
      }
      function selectWeek(index, forceProjection = false) {
        const changed=view.week!==index
        view.week = index
        for (const button of weekButtons.querySelectorAll('[data-week]')) button.setAttribute('aria-pressed', String(Number(button.dataset.week) === index))
        for (const row of reports.rows) for (const [column, cell] of [...row.cells].entries()) {
          if (weeks.some(w => w.index === column)) {
            mark(cell, 'data-edulog-week-cell', '')
            mark(cell, 'data-edulog-week-selected', column === index ? '' : null)
          }
        }
        const label=weeks.find(week=>week.index===index)?.label||''
        if(changed||forceProjection)doc.dispatchEvent(new doc.defaultView.CustomEvent('edulog:week-change',{detail:{index,label,mode:view.reportMode||'single'}}))
        if(changed&&typeof refreshReports==='function')refreshReports()
      }
      for (const week of weeks) {
        const button = element('button');button.textContent=week.label
        button.type = 'button'; button.dataset.week = String(week.index)
        listen(button, 'click', () => selectWeek(week.index)); weekButtons.append(button)
      }
      if (weeks.length) box.append(weekButtons)
      refreshReports = () => {
        const rows = [...reports.rows].filter(row => row.hasAttribute('data-edulog-report-row'))
        const activeWeek=view.week??selected?.index
        if(activeWeek!==undefined)view.week=activeWeek
        mark(reportScrollRegion,'data-edulog-report-mode',view.reportMode||'single')
        let visible = 0,otherSessionCount=0,unknownCount=0,attendanceCount=0,reportCount=0
        for (const row of rows) {
          const rowWeeks=weeks.map(week=>{
            const cell=row.cells[week.index],copy=cell?.cloneNode(true)
            copy?.querySelectorAll('a,button,input,select,textarea,[data-edulog-owned]').forEach(node=>node.remove())
            const value=copy?.textContent?.trim()||''
            const explicitOther=/此週非本班學生/.test(value)
            const linked=Boolean(row.querySelector(`td:nth-child(${week.index+1}) a[data-edulog-record-action],td:nth-child(${week.index+1}) a[href*="/reports/"]`))
            const attendancePending=/待確認出席|尚未確認出席|未登記出席|出席待確認/.test(value)
            const attendanceKnown=/出席|缺席|未出席/.test(value)&&!attendancePending
            const reportPending=/未填寫|待填寫|待補填/.test(value)
            const reportKnown=/已填寫課堂紀錄|課堂紀錄已完成|報告已完成/.test(value)&&!reportPending
            const statusKnown=/休假日|停課|課程取消|此週非本班學生|暫停課程|已完課|已啟用|待確認/.test(value)||attendanceKnown||attendancePending||reportKnown||reportPending
            return {week,value,explicitOther,linked,attendancePending,attendanceKnown,reportPending,reportKnown,statusKnown}
          })
          const selectedState=rowWeeks.find(item=>item.week.index===activeWeek)||rowWeeks[0]
          const isCompare=(view.reportMode||'single')==='compare'
          const otherSession=isCompare?rowWeeks.length>0&&rowWeeks.every(item=>item.explicitOther):Boolean(selectedState?.explicitOther)
          const relevant=isCompare?rowWeeks: selectedState?[selectedState]:[]
          const attendancePending=relevant.some(item=>item.attendancePending),reportPending=relevant.some(item=>item.reportPending)
          const filterMatches=view.reportFilter==='attendance'?attendancePending:view.reportFilter==='report'?reportPending:view.reportFilter==='unknown'?relevant.some(item=>(!item.attendanceKnown&&!item.attendancePending)||(!item.reportKnown&&!item.reportPending)):true
          if(!otherSession&&relevant.some(item=>!item.statusKnown||(!item.attendanceKnown&&!item.attendancePending)||(!item.reportKnown&&!item.reportPending)))unknownCount++
          if(!otherSession&&relevant.some(item=>item.attendanceKnown))attendanceCount++
          if(!otherSession&&relevant.some(item=>item.reportKnown))reportCount++
          if(otherSession)otherSessionCount++
          mark(row,'data-edulog-session-rank',otherSession?'other':selectedState?.linked?'current':'unknown')
          const matches = (row.getAttribute('data-edulog-student-name') || '').toLocaleLowerCase().includes(input.value.trim().toLocaleLowerCase())&&filterMatches&&(!otherSession||view.showOtherSessions===true)
          mark(row, 'data-edulog-filtered', matches ? null : '')
          const detail=row.nextElementSibling;if(detail?.hasAttribute('data-edulog-last-teaching-row'))detail.hidden=!matches||row.querySelector('.edulog-last-teaching-toggle')?.getAttribute('aria-expanded')!=='true'
          if (matches) visible++
        }
        if (selected) {
          mark(reports,'data-edulog-week-mode',view.reportMode||'single')
          for(const button of weekButtons.querySelectorAll('[data-report-mode]'))button.setAttribute('aria-pressed',String(button.dataset.reportMode===(view.reportMode||'single')))
          for(const button of weekButtons.querySelectorAll('[data-week]'))button.setAttribute('aria-pressed',String(Number(button.dataset.week)===activeWeek))
        }
        const currentCount=rows.length-otherSessionCount
        countNumbers[0].data=` ${visible} / ${currentCount} `;countNumbers[1].data=` ${attendanceCount} `;countNumbers[2].data=` ${reportCount} `;countNumbers[3].data=` ${unknownCount}`
        otherCount.textContent=String(otherSessionCount)
        if(typeof view.updateClassHistoryAvailability==='function')view.updateClassHistoryAvailability()
        view.reportQuery = input.value
      }
      const filterLabel=element('label','學生篩選'),filter=element('select');filter.setAttribute('aria-label','學生篩選')
      for(const [value,label] of [['all','本堂與待確認'],['attendance','待確認出席'],['report','待填紀錄'],['unknown','狀態未提供']]){const option=element('option',label);option.value=value;filter.append(option)}
      filter.value=view.reportFilter||'all';filter.dataset.edulogSearch='reportStatus';filterLabel.append(filter);box.append(filterLabel)
      const otherDetails=element('details');otherDetails.className='edulog-other-session-list';otherDetails.open=view.showOtherSessions===true
      const otherSummary=element('summary','非本堂學生 · '),otherCount=element('span','0');otherSummary.append(otherCount,element('span','（展開下方清單）'));otherDetails.append(otherSummary);box.append(otherDetails)
      listen(otherDetails,'toggle',()=>{view.showOtherSessions=otherDetails.open;refreshReports()})
      const historyTools=element('section');historyTools.className='edulog-class-history-tools';historyTools.setAttribute('aria-label','上次教學摘要')
      const availability=element('p');availability.setAttribute('role','status');availability.setAttribute('aria-live','polite');const availabilityValue=doc.createTextNode(' 0 '),availabilityWeek=element('span');availability.append(element('span','可讀取'),availabilityValue,element('span','位本堂學生的上次教學摘要 · 讀取課次：'),availabilityWeek)
      const loadAll=element('button','載入此課次全部摘要');loadAll.type='button'
      const stopAll=element('button','停止載入');stopAll.type='button';stopAll.hidden=true
      const progress=element('p');progress.setAttribute('role','status');progress.setAttribute('aria-live','polite')
      const progressStates=Object.fromEntries(['正在讀取','讀取進度','讀取完成；成功','已停止讀取；已完成的摘要會保留。'].map(key=>[key,element('span',key)]));for(const item of Object.values(progressStates))item.hidden=true
      const progressDone=doc.createTextNode(' 0 / 0 '),progressTotal=element('span','位已讀取 · 失敗需重試'),progressFailed=doc.createTextNode(' 0')
      progress.append(progressStates['正在讀取'],progressDone,progressTotal,progressStates['讀取進度'],progressStates['讀取完成；成功'],progressStates['已停止讀取；已完成的摘要會保留。'],progressFailed)
      historyTools.append(availability,loadAll,stopAll,progress);box.append(historyTools)
      view.classHistoryAvailability=availability
      view.classHistoryAvailabilityValue=availabilityValue
      view.classHistoryAvailabilityWeek=availabilityWeek
      let historyRun=0
      listen(loadAll,'click',async()=>{
        if(typeof view.loadClassHistory!=='function'){progress.textContent='目前版本無法載入整班摘要，請重新載入頁面後重試。';return}
        const run=++historyRun;loadAll.disabled=true;stopAll.hidden=false
        const total=Number(view.classHistoryEligibleCount)||0
        const showProgress=(label,value)=>{for(const [key,node] of Object.entries(progressStates))node.hidden=key!==label;progressDone.data=` ${value.done} / ${value.total} `;progressFailed.data=` ${value.failed}`}
        showProgress('正在讀取', {done:0,total,failed:0})
        const result=await view.loadClassHistory({isActive:()=>run===historyRun,onProgress:value=>{if(run===historyRun)showProgress('讀取進度',value)}})
        if(run!==historyRun)return
        stopAll.hidden=true;loadAll.disabled=false
        showProgress(result.cancelled?'已停止讀取；已完成的摘要會保留。':'讀取完成；成功',{done:result.done,total:result.total,failed:result.failed})
      })
      listen(stopAll,'click',()=>{historyRun++;view.cancelClassHistory?.();stopAll.hidden=true;loadAll.disabled=false;for(const [key,node] of Object.entries(progressStates))node.hidden=key!=='已停止讀取；已完成的摘要會保留。'})
      listen(filter,'change',()=>{view.reportFilter=filter.value;refreshReports()})
      listen(input, 'input', refreshReports); refreshReports()
      // Apply the initial week through the same projection used by later clicks.
      // The workflow has already enhanced the native rows, so this also moves
      // per-session actions into the selected cell before the table is shown.
      if(selected)selectWeek(selected.index,true)
    }
    const sourceTables = [...content.querySelectorAll('table')]
    const shape = sourceTables.map(table => ({ table, rows: table.rows.length }))
    return {
      page,
      isCurrent() {
        return doc.querySelector('#page-body > .content') === content && (!hoursInputs || hoursInputs.every(input => input.form === hoursForm && hoursForm.contains(input) && hoursForm.querySelector(`select[name=${input.name}]`) === input)) && sourceTables.length === content.querySelectorAll('table').length && shape.every(({ table, rows }) => table.isConnected && table.rows.length === rows)
      },
      refresh() {
        try { refreshStudents(); refreshReports(); workflow?.refresh() }
        catch (error) { scope.restore(); throw error }
      },
      restore: scope.restore,
    }
    } catch (error) { scope.restore(); throw error }
  }
  globalThis.edulogSiteAdapter = Object.freeze({
    id: 'orange-apple', matchesHost: host => host === 'corp.orangeapple.co',
    matchesTeachingPage: path => { const page = matchPage(path); return Boolean(page && page.kind !== 'report-editor') },
    matchesIntegrationPage: path => Boolean(matchPage(path)), matchPage, enhancePage,
    enhanceDialog(doc, view) {
      const scope = createScope(doc)
      try { return globalThis.edulogSiteWorkflows?.enhanceDialog(doc, view, scope) }
      catch (error) { scope.restore(); throw error }
    },
    enhanceDialogs(doc, view) {
      const scopes = []
      try { return globalThis.edulogSiteWorkflows?.enhanceDialogs(doc, view, document => {
        const scope = createScope(document); scopes.push(scope); return scope
      }) }
      catch (error) { for (const scope of scopes.reverse()) scope.restore(); throw error }
    },
    readContext: doc => ({ ...matchPage(doc.location.pathname), sourcePath: doc.location.pathname }),
  })
})()
